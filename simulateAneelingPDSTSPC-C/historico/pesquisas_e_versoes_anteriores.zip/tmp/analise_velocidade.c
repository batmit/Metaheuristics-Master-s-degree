#include <stdio.h>
#include <stdlib.h>
#include "SA.h"
#include "lerInstancias.h"
/* Comparacao exploratoria; nao altera parametros ou relatorio de producao. */
int main(void) {
    const char *nomes[]={"67-c-c","181-r-e"};
    const char *perfis[]={"exploracao","sem_macros","sem_diversidade","local_sem_BB"};
    puts("instancia,perfil,semente,avaliacoes,calibracao_s,busca_s,melhor");
    for(int c=0;c<2;c++) {
        char path[256];Instancia in={0};
        snprintf(path,sizeof path,"instances/pdstsp-c/large/%s.txt",nomes[c]);
        if(!lerInstancia(path,&in))return 1;
        alocarInstancias(&in);construirMatrizCaminhao(&in);
        snprintf(path,sizeof path,"instances/pdstsp-c/large/tau_kj_%s.txt",nomes[c]);
        if(!lerTemposDrone(path,&in))return 1;
        for(int seed=123;seed<=125;seed++)for(int k=0;k<4;k++) {
            ParametrosSA p=parametrosSAExploracao();p.limiteSegundos=.5;
            if(k==1||k==3)p.trocasSimultaneas=p.reconstrucaoParcial=false;
            if(k==2||k==3){p.elitesDiversas=false;p.maxRetomadas=0;}
            if(k==3)p.bbPeriodico=false;
            EstatisticasSA st={0};p.estatisticas=&st;
            Solucao s={0};alocarSolucao(&in,&s);srand((unsigned)seed);
            double t;
            if(!construirSolucaoInicial(&in,&s)||!resolverComCalibracaoSA(&in,&s,&p,&t))return 1;
            printf("%s,%s,%d,%llu,%.6f,%.6f,%.3f\n",nomes[c],perfis[k],seed,st.avaliacoes,st.segundosCalibracao,st.segundosBusca,s.makespan);
            fflush(stdout);liberarSolucao(&s);
        }
        liberarInstancia(&in);
    }
    return 0;
}
