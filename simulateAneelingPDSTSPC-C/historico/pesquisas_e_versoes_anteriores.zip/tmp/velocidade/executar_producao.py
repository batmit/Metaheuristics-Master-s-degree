import subprocess,time,json
from pathlib import Path
root=Path.cwd();dest=root/'resultados/avaliacao_velocidade_20261106'
start=time.perf_counter();lines=[]
with (dest/'execucao_producao.txt').open('w') as log:
 p=subprocess.Popen([str(root/'benchmark.exe')],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 for line in p.stdout:
  log.write(line);log.flush();lines.append(line);print(line,end='',flush=True)
 errors=p.stderr.read();code=p.wait()
seconds=time.perf_counter()-start
rows=[s.split() for s in lines[1:]]
assert code==0 and len(rows)==60 and len({r[0] for r in rows})==60 and not errors,(code,len(rows),errors)
result={'codigo_saida':code,'instancias':len(rows),'segundos':seconds,'erros':errors}
(dest/'execucao_producao.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
