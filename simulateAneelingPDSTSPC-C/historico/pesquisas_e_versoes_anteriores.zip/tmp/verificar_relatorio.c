#define main mainBenchmark
#include "../main.c"
#undef main
/* Confere a leitura real sem iniciar a busca nem modificar o CSV. */
int main(void)
{
    double melhores[TOTAL_CASOS];
    for (size_t c = 0; c < TOTAL_CASOS; c++) melhores[c] = INFINITY;
    if (!lerRelatorio(melhores)) return 1;
    size_t recuperadas = 0;
    for (size_t c = 0; c < TOTAL_CASOS; c++)
        if (isfinite(melhores[c])) recuperadas++;
    printf("Leitura OK: %zu resultados anteriores recuperados.\n", recuperadas);
    return 0;
}
