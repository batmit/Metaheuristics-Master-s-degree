import json,statistics,subprocess
from pathlib import Path
root=Path.cwd();dest=root/'tmp/velocidade'
with (dest/'candidato2.jsonl').open('w') as f:
 for c in range(60):
  r=subprocess.run([str(dest/'candidato2.exe'),str(c),'20261106','30'],cwd=root,capture_output=True,text=True,timeout=65)
  if r.returncode:raise RuntimeError((c,r.returncode,r.stderr))
  row=json.loads(r.stdout);row['perfil']='candidato2';f.write(json.dumps(row)+'\n');f.flush()
  print(c+1,row['melhor'],round(row['segundos'],3),flush=True)
a={x['instancia']:x for x in map(json.loads,(dest/'triagem.jsonl').read_text().splitlines()) if x['perfil']=='antes'}
b={x['instancia']:x for x in map(json.loads,(dest/'candidato2.jsonl').read_text().splitlines())}
d=[100*(b[n]['melhor']/a[n]['melhor']-1) for n in a]
print(json.dumps({'pares':len(d),'tempo_antes':sum(x['segundos'] for x in a.values()),'tempo_depois':sum(x['segundos'] for x in b.values()),'delta_medio_percentual':statistics.mean(d),'delta_maximo':max(d),'vitorias':sum(x<0 for x in d),'empates':sum(x==0 for x in d),'derrotas':sum(x>0 for x in d),'regressoes':[(n,a[n]['melhor'],b[n]['melhor']) for n in a if b[n]['melhor']>a[n]['melhor']]}),flush=True)
