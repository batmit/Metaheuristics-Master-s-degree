#define main appMain
#include "main.c"
#undef main
#include <assert.h>
/* Valida cobertura, duracoes, rota e capacidade sem chamar o avaliador da busca. */
static int certificado(const Instancia *in,const Solucao *s) {
    int vistos[512]={0};if(in->n>512)return 0;
    double truck=0,drone=0;int anterior=0;
    for(int i=0;i<s->numMissoesCaminhao;i++) {
        int j=s->missaoCaminhao[i].n;
        if(j<=0||j>=in->n||vistos[j]++)return 0;
        truck+=in->tempoCaminhao[anterior][j];anterior=j;
    }
    truck+=in->tempoCaminhao[anterior][0];
    for(int i=0;i<s->numMissoesDrone;i++) {
        MissaoDrone m=s->missaoDrone[i];int j=m.cliente,k=m.qtdDrones;
        if(j<=0||j>=in->n||vistos[j]++||!in->clientes[j].elegivelDrone||
           k<in->clientes[j].minDrones||k>in->numDrones)return 0;
        if(!isfinite(m.tempoInicio)||m.tempoInicio<0||!isfinite(m.tempoFim)||
           fabs(m.tempoFim-m.tempoInicio-in->tempoDrone[j][k])>1e-7)return 0;
        int uso=0;
        for(int h=0;h<s->numMissoesDrone;h++) {
            MissaoDrone x=s->missaoDrone[h];
            if(x.tempoInicio<=m.tempoInicio&&m.tempoInicio<x.tempoFim)uso+=x.qtdDrones;
        }
        if(uso>in->numDrones)return 0;
        drone=fmax(drone,m.tempoFim);
    }
    for(int j=1;j<in->n;j++)if(vistos[j]!=1)return 0;
    return isfinite(s->makespan)&&fabs(s->makespan-fmax(truck,drone))<1e-7;
}
/* Executa um caso isolado para comparacoes pareadas com fontes congeladas. */
int main(int argc,char **argv) {
    if(argc!=4)return 2;
    int c=atoi(argv[1]);unsigned seed=(unsigned)strtoul(argv[2],NULL,10);
    if(c<0||(size_t)c>=TOTAL_CASOS)return 2;
    double inicio=relogioSA();Instancia in={0};Solucao s={0};
    if(!carregarCaso(&casos[c],&in))return 3;
#ifdef BENCH_NEW
    ParametrosSA p=parametrosSARapido();
#else
    ParametrosSA p=parametrosSAFoco165();
#endif
    if(strcmp(casos[c].nome,"165-r-c"))
        p.reparoDirigido=p.cadeiasEjecao=p.filtrosReparo=p.reparoCP=false;
    p.movimentosGrupo=true;p.limiteSegundos=strtod(argv[3],NULL);
    EstatisticasSA st={0};p.estatisticas=&st;
    alocarSolucao(&in,&s);srand(seed);double temperatura;
    if(!construirSolucaoInicial(&in,&s)||!resolverComCalibracaoSA(&in,&s,&p,&temperatura))return 4;
    double segundos=relogioSA()-inicio;
    int valido=certificado(&in,&s);
    printf("{\"instancia\":\"%s\",\"semente\":%u,\"melhor\":%.9f,\"literatura2025\":%.9f,\"segundos\":%.6f,\"avaliacoes\":%llu,\"calibracao\":%.6f,\"macros\":%llu,\"cp\":%llu,\"valido\":%s}\n",
        casos[c].nome,seed,s.makespan,casos[c].literatura2025,segundos,st.avaliacoes,
        st.segundosCalibracao,st.trocas+st.reconstrucoes,st.reparo.chamadasCP,valido?"true":"false");
    liberarSolucao(&s);liberarInstancia(&in);return valido?0:5;
}
