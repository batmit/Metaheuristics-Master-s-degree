import json,subprocess,time
from pathlib import Path
root=Path.cwd();dest=root/'tmp/velocidade'
with (dest/'triagem.jsonl').open('w') as f:
 for c in range(60):
  for perfil in (['antes','depois'] if c%2==0 else ['depois','antes']):
   cap=5 if perfil=='antes' else 30
   r=subprocess.run([str(dest/(perfil+'.exe')),str(c),'20261106',str(cap)],cwd=root,capture_output=True,text=True,timeout=65)
   if r.returncode:raise RuntimeError((c,perfil,r.returncode,r.stderr))
   row=json.loads(r.stdout);row['perfil']=perfil;row['limite']=cap;f.write(json.dumps(row)+'\n');f.flush()
  print(c+1,flush=True)
