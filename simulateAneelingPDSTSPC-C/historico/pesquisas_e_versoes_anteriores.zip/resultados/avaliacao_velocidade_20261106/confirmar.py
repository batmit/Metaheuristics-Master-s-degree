import csv,json,subprocess,statistics
from pathlib import Path
root=Path.cwd();dest=root/'tmp/velocidade'
with (root/'resultados/revisao_literatura_2025/comparacao_60_instancias.csv').open(encoding='utf-8-sig') as f:
 names=[r['instance'] for r in csv.DictReader(f)]
selected=['67-c-c','165-r-c','167-r-e','181-r-e']
with (dest/'confirmacao.jsonl').open('w') as f:
 for seed in [20261106,20261107,20261108]:
  for name in selected:
   c=names.index(name)
   order=['antes','candidato2'] if (c+seed)%2==0 else ['candidato2','antes']
   for perfil in order:
    r=subprocess.run([str(dest/(perfil+'.exe')),str(c),str(seed),'30'],cwd=root,capture_output=True,text=True,timeout=65)
    if r.returncode:raise RuntimeError((name,seed,perfil,r.returncode,r.stderr))
    row=json.loads(r.stdout);row['perfil']=perfil;f.write(json.dumps(row)+'\n');f.flush()
    print(name,seed,perfil,row['melhor'],round(row['segundos'],3),flush=True)
a={};b={}
for x in map(json.loads,(dest/'confirmacao.jsonl').read_text().splitlines()):
 (a if x['perfil']=='antes' else b)[x['instancia'],x['semente']]=x
print('RESUMO',json.dumps({'tempo_antes':sum(x['segundos'] for x in a.values()),'tempo_depois':sum(x['segundos'] for x in b.values()),'delta_medio_percentual':statistics.mean(100*(b[n]['melhor']/a[n]['melhor']-1) for n in a),'por_instancia':{name:{'antes':[a[n]['melhor'] for n in a if n[0]==name],'depois':[b[n]['melhor'] for n in a if n[0]==name]} for name in selected}}),flush=True)
