# Avaliacao do perfil rapido � 06/11/2026

Perfil mantido: atende aos criterios de reducao de tempo >=60% e piora media relativa de makespan <=2% tanto na triagem quanto na confirmacao. A primeira configuracao, mais agressiva, foi rejeitada por perda de qualidade.

## Alteracoes mantidas

- Resfriamento geometrico; temperatura final encerra a busca. O prazo de 30 s e teto, sem obrigacao de esgota-lo.
- Parada apos 400 niveis sem melhora global, condicionada a pelo menos 200 mil avaliacoes. O termino natural pode ocorrer antes. No maximo duas retomadas.
- Um macromovimento por nivel apos cinco niveis estagnados; calibracao mista original preservada.
- Comparacoes de atribuicao com bitsets na pilha (sem malloc/free no benchmark); filtro de makespan antes das comparacoes de diversidade.
- B&B periodico e reparos dirigidos/CP-SAT desativados no perfil rapido. Uma chamada final opcional de B&B, limitada a 10 mil nos, atua somente no melhor resultado.
- Perfis anteriores preservados; main usa parametrosSARapido(). Avaliacao incremental e caches dos drones mantidos.

## Metodo

C11, gcc -O2 -Wall -Wextra -pedantic, execucoes sequenciais sem carga de testes concorrente. Tempos incluem carregamento, construcao inicial, calibracao, busca e refinamento final; medicao termina antes da validacao do certificado. As sementes sao pareadas, mas mudancas na busca mudam os sorteios subsequentes.

Triagem: todas as 60 instancias, semente 20261106; versao anterior limitada a 5 s por caso, candidata com teto de 30 s e encerramento antecipado. Baselines foram coletadas durante a primeira triagem, candidata selecionada em lote posterior. A triagem nao mede a versao anterior a 30 s nas 60 instancias.

Confirmacao: 67-c-c, 165-r-c, 167-r-e e 181-r-e; sementes 20261106, 20261107 e 20261108; teto de 30 s para ambas. Ordem alternada por par, uma execucao de cada versao. Tres sementes nao estabelecem garantia estatistica geral.

Cada solucao passou por verificacao independente do avaliador da busca: cobertura exata, rota e retorno, elegibilidade, duracoes e capacidade simultanea dos drones. Nenhum resultado historico do CSV participa das comparacoes.

## Resultados

| Ensaio | Pares | Tempo anterior (s) | Tempo rapido (s) | Reducao | Delta medio do makespan | Melhora/empate/piora |
|---|---:|---:|---:|---:|---:|---|
| 60 instancias (anterior 5 s) | 60 | 300.832 | 112.196 | 62.70% | -0.209% | 12/39/9 |
| 4 abertas x 3 sementes (anterior 30 s) | 12 | 360.207 | 46.992 | 86.95% | +0.679% | 2/6/4 |

Delta medio = media aritmetica de 100*(rapido/anterior-1) por par; negativo e melhoria. A diferenca maxima individual na triagem foi 5.263%. Reduzir o tempo nao garante empate em cada instancia ou semente.

### Confirmacao por instancia

| Instancia | Resultados anteriores | Resultados rapidos | Tempo medio anterior (s) | Tempo medio rapido (s) |
|---|---|---|---:|---:|
| 67-c-c | 76, 76, 76 | 80, 76, 76 | 30.002 | 0.915 |
| 165-r-c | 164, 168, 164 | 168, 168, 168 | 30.016 | 5.313 |
| 167-r-e | 196, 192, 188 | 196, 188, 188 | 30.024 | 4.709 |
| 181-r-e | 232, 232, 220 | 228, 232, 224 | 30.027 | 4.727 |

## Reproducao e arquivos

Fontes congeladas em fontes_antes/ e fontes_depois/. Hashes e metricas em resumo.json. benchmark.c inclui a main da versao selecionada, renomeia seu ponto de entrada e usa suas instancias. Compile a partir da raiz com -I resultados/avaliacao_velocidade_20261106/fontes_antes e os arquivos SA.c, cv.c e lerInstancias.c dessa pasta. Para a candidata use fontes_depois e -DBENCH_NEW. Os executaveis de ensaio recebem indice do caso (0..59), semente e teto em segundos. O executavel de producao continua sem argumentos.

comparar.py registra a primeira triagem; candidato2.py a candidata selecionada; confirmar.py a confirmacao. Os scripts originais usam tmp/velocidade como pasta de trabalho dos ensaios. Os JSONL preservam todas as medicoes. O unico CSV ativo da aplicacao continua sendo resultados/relatorio.csv.

## Verificacao final

17 testes C aprovados, incluindo test_sa_rapido, mais o teste de integracao do relatorio (60 casos, persistencia, UTF-8/BOM, LF/CRLF e arquivo vazio). Compilacao final sem avisos.

O benchmark.exe final foi executado sem argumentos: 60 instancias, codigo de saida 0, sem erros, em 146.861 s (2.45 minutos). Esse lote usa semente do relogio e atualiza o CSV historico; sua tabela nao representa resultados isolados para comparacao de qualidade. Os 112.196 s da triagem usam a semente fixa 20261106 e nao sao o tempo desse lote final.
