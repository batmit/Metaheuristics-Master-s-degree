#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <math.h>
#include <errno.h>
#ifdef _WIN32
#include <windows.h>
#include <direct.h>
#include <wchar.h>
#else
#include <sys/stat.h>
#endif

/* Parametros do lote: uma busca por instancia, sem argumentos de terminal. */
#ifndef SA_SEGUNDOS_POR_INSTANCIA
#define SA_SEGUNDOS_POR_INSTANCIA 30.0
#endif
#include "SA.h"
#include "main.h"
#include "lerInstancias.h"
#include "cv.h"

typedef struct CasoBenchmark {
    const char *nome;
    const char *pasta;
    double literatura2024;
    double literatura2025;
} CasoBenchmark;

/* Referencias UB de 2024 e 2025 da revisao local das 60 instancias.
 * Fonte e evidencias: resultados/revisao_literatura_2025/.
 * A pasta segue o catalogo oficial de entradas. */
static const CasoBenchmark casos[] = {
    {"15-r-e", "small", 92.0, 92.0},
    {"15-rc-c", "small", 44.0, 44.0},
    {"16-c-c", "small", 60.0, 60.0},
    {"16-r-e", "small", 112.0, 112.0},
    {"18-c-c", "small", 56.0, 56.0},
    {"18-r-e", "small", 96.0, 96.0},
    {"18-rc-c", "small", 57.0, 57.0},
    {"19-c-c", "small", 44.0, 44.0},
    {"20-c-c", "small", 43.0, 43.0},
    {"20-r-c", "small", 64.0, 64.0},
    {"20-r-e", "small", 80.0, 80.0},
    {"20-rc-c", "small", 96.0, 96.0},
    {"20-rc-e", "small", 100.0, 100.0},
    {"21-c-c", "small", 62.0, 62.0},
    {"21-r-e", "small", 85.0, 85.0},
    {"23-c-e", "small", 80.0, 80.0},
    {"23-r-c", "small", 88.0, 88.0},
    {"24-c-e", "small", 84.0, 84.0},
    {"24-r-e", "small", 112.0, 112.0},
    {"24-rc-c", "small", 70.0, 70.0},
    {"25-c-c", "small", 56.0, 56.0},
    {"25-r-e", "small", 104.0, 104.0},
    {"25-rc-e", "small", 92.0, 92.0},
    {"26-r-c", "small", 103.0, 103.0},
    {"27-c-c", "small", 84.0, 84.0},
    {"27-c-e", "small", 68.0, 68.0},
    {"27-rc-c", "small", 100.0, 100.0},
    {"27-rc-e", "small", 84.0, 84.0},
    {"29-rc-e", "small", 116.0, 116.0},
    {"30-c-c", "small", 96.0, 96.0},
    {"50-r-e", "large", 116.0, 116.0},
    {"53-r-e", "large", 132.0, 132.0},
    {"66-rc-e", "large", 124.0, 124.0},
    {"67-c-c", "large", 76.0, 74.0},
    {"68-rc-c", "large", 76.0, 76.0},
    {"76-c-c", "large", 52.0, 52.0},
    {"82-c-e", "large", 64.0, 64.0},
    {"82-rc-c", "large", 104.0, 104.0},
    {"88-c-e", "large", 108.0, 108.0},
    {"91-r-c", "large", 124.0, 120.0},
    {"99-rc-c", "large", 100.0, 99.0},
    {"101-r-c", "large", 120.0, 116.0},
    {"103-rc-c", "large", 124.0, 120.0},
    {"105-rc-e", "large", 120.0, 112.0},
    {"108-rc-e", "large", 136.0, 135.0},
    {"114-rc-c", "large", 96.0, 96.0},
    {"121-rc-e", "large", 124.0, 121.0},
    {"126-r-c", "large", 160.0, 152.0},
    {"126-rc-e", "large", 144.0, 136.0},
    {"144-rc-c", "large", 128.0, 124.0},
    {"154-c-c", "large", 72.0, 68.0},
    {"165-r-c", "large", 164.0, 160.0},
    {"167-r-e", "large", 188.0, 180.0},
    {"173-r-c", "large", 164.0, 160.0},
    {"173-rc-c", "large", 133.0, 130.0},
    {"181-r-e", "large", 224.0, 216.0},
    {"185-c-c", "large", 96.0, 96.0},
    {"187-rc-e", "large", 196.0, 188.0},
    {"198-c-c", "large", 64.0, 64.0},
    {"200-r-e", "large", 212.0, 200.0},
};

/* Carrega uma instancia e suas matrizes uma unica vez por lote. */
static int carregarCaso(const CasoBenchmark *caso, Instancia *inst)
{
    char arquivo[256];
    snprintf(arquivo, sizeof arquivo, "instances/pdstsp-c/%s/%s.txt", caso->pasta, caso->nome);
    if (!lerInstancia(arquivo, inst)) return 0;
    alocarInstancias(inst);
    if (!inst->tempoCaminhao || !inst->tempoDrone) return 0;
    for (int i = 0; i < inst->n; i++)
        if (!inst->tempoCaminhao[i] || !inst->tempoDrone[i]) return 0;
    construirMatrizCaminhao(inst);
    snprintf(arquivo, sizeof arquivo, "instances/pdstsp-c/%s/tau_kj_%s.txt", caso->pasta, caso->nome);
    return lerTemposDrone(arquivo, inst);
}

/* Reconstroi a solucao a cada repeticao, preservando as matrizes da instancia. */
static int resolverCaso(Instancia *inst, const CasoBenchmark *caso,
                       const ParametrosSA *configuracao, double *resultado)
{
    Solucao solucao = {0};
    ParametrosSA p = *configuracao;
    if (strcmp(caso->nome, "165-r-c"))
        p.reparoDirigido = p.cadeiasEjecao = p.filtrosReparo = p.reparoCP = false;
    p.movimentosGrupo = true;
    alocarSolucao(inst, &solucao);
    int ok = solucao.missaoCaminhao && solucao.missaoDrone && solucao.prefixosDrone;
    double temperatura;
    if (ok) ok = construirSolucaoInicial(inst, &solucao) &&
                 resolverComCalibracaoSA(inst, &solucao, &p, &temperatura);
    if (ok) *resultado = solucao.makespan;
    liberarSolucao(&solucao);
    return ok;
}

#define RELATORIO "resultados/relatorio.csv"
#define TOTAL_CASOS (sizeof casos / sizeof casos[0])
static const char cabecalho[] = "instancia,melhor_algoritmo,literatura_2024,literatura_2025,gap_percentual\n";

/* Recupera os melhores, aceitando UTF-8 com BOM e finais de linha LF/CRLF. */
static int lerRelatorio(double melhores[TOTAL_CASOS])
{
    FILE *f = fopen(RELATORIO, "rb");
    if (!f) {
        if (errno == ENOENT) return 1;
        perror("Nao foi possivel abrir " RELATORIO);
        return 0;
    }
    char linha[512], nome[64];
    if (!fgets(linha, sizeof linha, f)) {
        /* Arquivo vazio ainda nao contem resultados; sera inicializado no lote. */
        int ok = !ferror(f);
        if (!ok) perror("Erro de leitura em " RELATORIO);
        if (fclose(f)) ok = 0;
        return ok;
    }
    char *titulo = linha;
    if (strncmp(titulo, "\xEF\xBB\xBF", 3) == 0) titulo += 3;
    titulo[strcspn(titulo, "\r\n")] = '\0';
    size_t esperado = strcspn(cabecalho, "\r\n");
    if (strlen(titulo) != esperado || strncmp(titulo, cabecalho, esperado)) {
        fprintf(stderr, "Cabecalho invalido em " RELATORIO
                ". Esperado: %s", cabecalho);
        fclose(f);
        return 0;
    }
    while (fgets(linha, sizeof linha, f)) {
        double valor;
        if (sscanf(linha, "%63[^,],%lf", nome, &valor) != 2 || !isfinite(valor) || valor <= 0) continue;
        for (size_t c = 0; c < TOTAL_CASOS; c++)
            if (!strcmp(nome, casos[c].nome) && valor < melhores[c]) melhores[c] = valor;
    }
    int ok = !ferror(f);
    if (!ok) perror("Erro de leitura em " RELATORIO);
    if (fclose(f)) ok = 0;
    return ok;
}

/* Grava uma linha no CSV; vazio indica ausencia de resultado. */
static void escreverLinha(FILE *f, size_t c, double melhor)
{
    const CasoBenchmark *caso = &casos[c];
    if (isfinite(melhor))
        fprintf(f, "%s,%.9f,%.9f,%.9f,%.9f\n", caso->nome, melhor,
                caso->literatura2024, caso->literatura2025,
                100.0 * (melhor - caso->literatura2025) / caso->literatura2025);
    else fprintf(f, "%s,,%.9f,%.9f,\n", caso->nome, caso->literatura2024, caso->literatura2025);
}

/* Consolida uma linha por instancia preservando os melhores anteriores. */
static int salvarRelatorio(const double melhores[TOTAL_CASOS])
{
    FILE *f = fopen(RELATORIO, "w");
    if (!f) return 0;
    fputs(cabecalho, f);
    for (size_t c = 0; c < TOTAL_CASOS; c++) escreverLinha(f, c, melhores[c]);
    int ok = !ferror(f);
    if (fclose(f)) ok = 0;
    return ok;
}

/* Localiza as entradas ao abrir por duplo clique e cria a pasta de saida. */
static int prepararDiretorio(void)
{
#ifdef _WIN32
    /* Caminho UTF-16 suporta nomes de usuario e pastas com acentos. */
    wchar_t caminho[32768];
    DWORD tamanho = GetModuleFileNameW(NULL, caminho, 32768);
    if (!tamanho || tamanho >= 32768) return 0;
    wchar_t *barra = wcsrchr(caminho, L'\\');
    if (!barra) return 0;
    *barra = L'\0';
    if (!SetCurrentDirectoryW(caminho)) return 0;
    return _mkdir("resultados") == 0 || errno == EEXIST;
#else
    return mkdir("resultados", 0755) == 0 || errno == EEXIST;
#endif
}

/* Mostra somente os campos do relatorio em colunas alinhadas. */
static void mostrarResultado(size_t c, double melhor)
{
    const CasoBenchmark *caso = &casos[c];
    if (isfinite(melhor))
        printf("%-12s %18.2f %16.2f %16.2f %12.2f\n", caso->nome, melhor,
               caso->literatura2024, caso->literatura2025,
               100.0 * (melhor - caso->literatura2025) / caso->literatura2025);
    else printf("%-12s %18s %16.2f %16.2f %12s\n", caso->nome, "--",
                caso->literatura2024, caso->literatura2025, "--");
    fflush(stdout);
}

/* Executa exatamente uma busca para cada uma das 60 instancias. */
static int executarLote(void)
{
    if (!prepararDiretorio()) {
        perror("Falha ao preparar diretorio do executavel");
        return EXIT_FAILURE;
    }
    ParametrosSA configuracao = parametrosSAFoco165();
    configuracao.limiteSegundos = SA_SEGUNDOS_POR_INSTANCIA;
    unsigned int semente = (unsigned int)time(NULL);
    double melhores[TOTAL_CASOS];
    for (size_t c = 0; c < TOTAL_CASOS; c++) melhores[c] = INFINITY;
    if (!lerRelatorio(melhores)) {
        fprintf(stderr, "Falha ao ler " RELATORIO ".\n");
        return EXIT_FAILURE;
    }
    int sucesso = 1;
    printf("%-12s %18s %16s %16s %12s\n", "Instancia", "Melhor algoritmo",
           "Literatura 2024", "Literatura 2025", "Gap (%)");
    fflush(stdout);
    for (size_t c = 0; c < TOTAL_CASOS; c++) {
        Instancia inst = {0};
        double resultado;
        srand(semente + (unsigned int)c);
        if (!carregarCaso(&casos[c], &inst)) {
            fprintf(stderr, "Falha ao carregar %s.\n", casos[c].nome);
            sucesso = 0;
        } else if (!resolverCaso(&inst, &casos[c], &configuracao, &resultado)) {
            fprintf(stderr, "Falha ao resolver %s.\n", casos[c].nome);
            sucesso = 0;
        } else if (resultado < melhores[c]) melhores[c] = resultado;
        liberarInstancia(&inst);
        if (!salvarRelatorio(melhores)) {
            perror("Falha ao salvar " RELATORIO);
            return EXIT_FAILURE;
        }
        mostrarResultado(c, melhores[c]);
    }
    return sucesso ? EXIT_SUCCESS : EXIT_FAILURE;
}

/* Ao abrir com duplo clique, conserva a tabela na janela ate pressionar Enter. */
int main(void)
{
    int resultado = executarLote();
#ifdef _WIN32
    DWORD processos[2];
    if (GetConsoleProcessList(processos, 2) == 1) {
        fprintf(stderr, "\nPressione Enter para fechar.\n");
        (void)getchar();
    }
#endif
    return resultado;
}
