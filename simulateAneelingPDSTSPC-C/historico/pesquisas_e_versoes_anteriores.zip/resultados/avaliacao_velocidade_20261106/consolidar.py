import json,hashlib,shutil,csv,statistics
from pathlib import Path
root=Path.cwd();src=root/'tmp/velocidade';out=root/'resultados/avaliacao_velocidade_20261106'
# Executar somente depois de concluir os ensaios e a suite de testes.
def summarize(a,b):
 delta=[100*(b[k]['melhor']/a[k]['melhor']-1) for k in a]
 ta=sum(x['segundos'] for x in a.values());tb=sum(x['segundos'] for x in b.values())
 return {'pares':len(a),'tempo_antes':ta,'tempo_depois':tb,'reducao_percentual':100*(1-tb/ta),'delta_medio_percentual':statistics.mean(delta),'delta_maximo_percentual':max(delta),'melhorias':sum(v<0 for v in delta),'empates':sum(v==0 for v in delta),'pioras':sum(v>0 for v in delta)}
def read(name):return [json.loads(s) for s in (src/name).read_text().splitlines()]
a={r['instancia']:r for r in read('triagem.jsonl') if r['perfil']=='antes'}
b={r['instancia']:r for r in read('candidato2.jsonl')}
raw=read('confirmacao.jsonl')
x={(r['instancia'],r['semente']):r for r in raw if r['perfil']=='antes'}
y={(r['instancia'],r['semente']):r for r in raw if r['perfil']=='candidato2'}
assert len(a)==len(b)==60 and len(x)==len(y)==12
assert all(r['valido'] for r in list(a.values())+list(b.values())+raw)
screen=summarize(a,b);confirmation=summarize(x,y)
accepted=all(s['reducao_percentual']>=60 and s['delta_medio_percentual']<=2 for s in (screen,confirmation))
if not accepted:raise SystemExit('Criterio nao atendido: '+str((screen,confirmation)))
out.mkdir(exist_ok=True)
for name in ['triagem.jsonl','candidato2.jsonl','confirmacao.jsonl','benchmark.c','comparar.py','candidato2.py','confirmar.py']:
 shutil.copy2(src/name,out/name)
files=['main.c','main.h','SA.c','SA.h','cv.c','cv.h','lerInstancias.c','lerInstancias.h','reparo_alvo.inc']
manifest={'criterio':{'reducao_minima_percentual':60,'piora_media_maxima_percentual':2},'aceito':accepted,'triagem':screen,'confirmacao':confirmation,'hashes':{}}
for version,folder in [('antes',src/'antes'),('depois',root)]:
 target=out/('fontes_'+version);target.mkdir(exist_ok=True)
 for name in files:
  shutil.copy2(folder/name,target/name)
  manifest['hashes'][version+'/'+name]=hashlib.sha256((folder/name).read_bytes()).hexdigest()
(out/'resumo.json').write_text(json.dumps(manifest,indent=2))
lines=['# Avaliacao do perfil rapido — 06/11/2026','',
'Perfil mantido: atende aos criterios de reducao de tempo >=60% e piora media relativa de makespan <=2% tanto na triagem quanto na confirmacao. A primeira configuracao, mais agressiva, foi rejeitada por perda de qualidade.','',
'## Alteracoes mantidas','',
'- Resfriamento geometrico; temperatura final encerra a busca. O prazo de 30 s e teto, sem obrigacao de esgota-lo.',
'- Parada apos 400 niveis sem melhora global, condicionada a pelo menos 200 mil avaliacoes. O termino natural pode ocorrer antes. No maximo duas retomadas.',
'- Um macromovimento por nivel apos cinco niveis estagnados; calibracao mista original preservada.',
'- Comparacoes de atribuicao com bitsets na pilha (sem malloc/free no benchmark); filtro de makespan antes das comparacoes de diversidade.',
'- B&B periodico e reparos dirigidos/CP-SAT desativados no perfil rapido. Uma chamada final opcional de B&B, limitada a 10 mil nos, atua somente no melhor resultado.',
'- Perfis anteriores preservados; main usa parametrosSARapido(). Avaliacao incremental e caches dos drones mantidos.','',
'## Metodo','',
'C11, gcc -O2 -Wall -Wextra -pedantic, execucoes sequenciais sem carga de testes concorrente. Tempos incluem carregamento, construcao inicial, calibracao, busca e refinamento final; medicao termina antes da validacao do certificado. As sementes sao pareadas, mas mudancas na busca mudam os sorteios subsequentes.','',
'Triagem: todas as 60 instancias, semente 20261106; versao anterior limitada a 5 s por caso, candidata com teto de 30 s e encerramento antecipado. Baselines foram coletadas durante a primeira triagem, candidata selecionada em lote posterior. A triagem nao mede a versao anterior a 30 s nas 60 instancias.','',
'Confirmacao: 67-c-c, 165-r-c, 167-r-e e 181-r-e; sementes 20261106, 20261107 e 20261108; teto de 30 s para ambas. Ordem alternada por par, uma execucao de cada versao. Tres sementes nao estabelecem garantia estatistica geral.','',
'Cada solucao passou por verificacao independente do avaliador da busca: cobertura exata, rota e retorno, elegibilidade, duracoes e capacidade simultanea dos drones. Nenhum resultado historico do CSV participa das comparacoes.','',
'## Resultados','',
'| Ensaio | Pares | Tempo anterior (s) | Tempo rapido (s) | Reducao | Delta medio do makespan | Melhora/empate/piora |',
'|---|---:|---:|---:|---:|---:|---|']
for label,s in [('60 instancias (anterior 5 s)',screen),('4 abertas x 3 sementes (anterior 30 s)',confirmation)]:
 lines.append(f"| {label} | {s['pares']} | {s['tempo_antes']:.3f} | {s['tempo_depois']:.3f} | {s['reducao_percentual']:.2f}% | {s['delta_medio_percentual']:+.3f}% | {s['melhorias']}/{s['empates']}/{s['pioras']} |")
lines+=['','Delta medio = media aritmetica de 100*(rapido/anterior-1) por par; negativo e melhoria. A diferenca maxima individual na triagem foi %.3f%%. Reduzir o tempo nao garante empate em cada instancia ou semente.'%screen['delta_maximo_percentual'],'',
'### Confirmacao por instancia','',
'| Instancia | Resultados anteriores | Resultados rapidos | Tempo medio anterior (s) | Tempo medio rapido (s) |','|---|---|---|---:|---:|']
for name in ['67-c-c','165-r-c','167-r-e','181-r-e']:
 keys=sorted(k for k in x if k[0]==name)
 lines.append('| %s | %s | %s | %.3f | %.3f |'%(name,', '.join(f"{x[k]['melhor']:g}" for k in keys),', '.join(f"{y[k]['melhor']:g}" for k in keys),statistics.mean(x[k]['segundos'] for k in keys),statistics.mean(y[k]['segundos'] for k in keys)))
lines+=['','## Reproducao e arquivos','',
'Fontes congeladas em fontes_antes/ e fontes_depois/. Hashes e metricas em resumo.json. benchmark.c inclui a main da versao selecionada, renomeia seu ponto de entrada e usa suas instancias. Compile a partir da raiz com -I resultados/avaliacao_velocidade_20261106/fontes_antes e os arquivos SA.c, cv.c e lerInstancias.c dessa pasta. Para a candidata use fontes_depois e -DBENCH_NEW. Os executaveis de ensaio recebem indice do caso (0..59), semente e teto em segundos. O executavel de producao continua sem argumentos.','',
'comparar.py registra a primeira triagem; candidato2.py a candidata selecionada; confirmar.py a confirmacao. Os scripts originais usam tmp/velocidade como pasta de trabalho dos ensaios. Os JSONL preservam todas as medicoes. O unico CSV ativo da aplicacao continua sendo resultados/relatorio.csv.']
(out/'relatorio.md').write_text('\n'.join(lines)+'\n')
# Consolida somente resultados com certificado validado, inclusive do perfil anterior.
report=root/'resultados/relatorio.csv'
with report.open(encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f);fields=reader.fieldnames;rows=list(reader)
for row in rows:
 vals=[r['melhor'] for r in list(a.values())+list(b.values())+raw if r['instancia']==row['instancia'] and r['valido']]
 if row['melhor_algoritmo']:vals.append(float(row['melhor_algoritmo']))
 if vals:
  value=min(vals);row['melhor_algoritmo']=f'{value:.9f}'
  row['gap_percentual']=f"{100*(value-float(row['literatura_2025']))/float(row['literatura_2025']):.9f}"
with report.open('w',newline='') as f:
 w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
print(json.dumps({'triagem':screen,'confirmacao':confirmation,'mantido':accepted}),flush=True)
