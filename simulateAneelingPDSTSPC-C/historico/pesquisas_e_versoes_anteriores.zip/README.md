# PDSTSP-C com Simulated Annealing

Compile na raiz do projeto:

```powershell
gcc -O2 -std=c11 -Wall -Wextra -pedantic main.c cv.c lerInstancias.c SA.c -lm -o benchmark.exe
```

Abra `benchmark.exe` com duplo clique ou execute no PowerShell:

```powershell
.\benchmark.exe
```

No Git Bash, use `./benchmark.exe`. `.benchmark.exe` nao e o nome correto.
Nao e necessario informar parametros nem responder perguntas para iniciar.

O executavel percorre as **60 instancias**, em ordem crescente de tamanho,
e executa o algoritmo **uma unica vez por instancia**. Mostra o cabecalho
imediatamente e acrescenta uma linha assim que cada caso termina, com descarga
imediata da saida. A tabela tem somente instancia, melhor algoritmo, literatura
2024, literatura 2025 e gap. Ao abrir com duplo clique no Windows, a janela
permanece aberta ao final ate pressionar Enter.

O perfil rapido encerra pelo resfriamento geometrico ou por estagnacao.
Os 30 segundos em `SA_SEGUNDOS_POR_INSTANCIA` sao um teto por instancia,
nao um tempo que precisa ser consumido. A parada por estagnacao exige
400 niveis sem melhoria global e pelo menos 200 mil avaliacoes. O resfriamento
pode encerrar antes desse minimo, que se aplica apenas a estagnacao.
A calibracao mista foi preservada; sao permitidas no maximo duas retomadas.
Movimentos compostos ocorrem uma vez por nivel apos cinco niveis sem melhoria.
A manutencao da elite usa bitsets sem alocacao dinamica no benchmark.
B&B periodico, reparos dirigidos e CP-SAT ficam desativados no perfil rapido.
Uma chamada final de B&B, limitada a 10 mil nos, refina somente o melhor;
`refinoFinalBB=false` desativa tambem essa chamada. O teto e verificado entre
operacoes: inicializacao e um refinamento em andamento podem acrescentar tempo.

Os parametros ficam no codigo; nao ha configuracao por argumentos de terminal.
O Windows localiza as entradas e o CSV a partir da pasta do executavel,
inclusive quando iniciado por um atalho com outra pasta de trabalho.
Mantenha o executavel na raiz, ao lado da pasta `instances`.
A pasta `resultados` e criada automaticamente quando necessario.

## Relatorio unico

`resultados/relatorio.csv` tem uma linha por instancia:

| Coluna | Significado |
| --- | --- |
| instancia | Nome do arquivo, sem extensao |
| melhor_algoritmo | Menor makespan encontrado pelo algoritmo ate agora |
| literatura_2024 | Melhor solucao viavel reportada em 2024 |
| literatura_2025 | Melhor solucao viavel reportada no pacote ORLab de 2025 |
| gap_percentual | 100 * (melhor_algoritmo - literatura_2025) / literatura_2025 |

Tempos em minutos. Gap negativo indica melhoria sobre a referencia de 2025;
zero indica empate. As referencias sao limites superiores, sem afirmacao de
otimalidade. Valores e evidencias estao na
[revisao local](resultados/revisao_literatura_2025/relatorio_revisao_2024_2025.md).
Nao ha consulta online durante a execucao.

O CSV e lido ao iniciar e atualizado apos cada instancia. A leitura aceita
UTF-8 com ou sem BOM e quebras de linha Windows (CRLF) ou Linux (LF).
Um arquivo vazio e inicializado automaticamente. Resultados
piores nao substituem o melhor anterior. Campos vazios indicam que ainda nao existe resultado do
algoritmo; nao sao preenchidos com valores da literatura. A migracao inicial
consolidou os menores valores dos antigos resumos da raiz de `resultados`.
Esses arquivos estao preservados em `resultados/historico/`; experimentos e
fontes anteriores permanecem como arquivo e nao sao atualizados pelo executavel.

A tabela no terminal mostra o melhor acumulado, que pode vir de uma execucao
anterior. Somente erros aparecem em stderr durante a busca.
Execute apenas um processo por vez para evitar disputa pelo mesmo CSV.
Para iniciar um historico novo, guarde o CSV atual em outra pasta antes de rodar.

A configuracao de producao usa `parametrosSARapido()` em `SA.c`.
Os perfis anteriores `parametrosSAExploracao()` e `parametrosSAFoco165()`
continuam disponiveis para comparacao, inclusive o reparo CP-SAT da 165-r-c.
Eles nao sao executados pelo perfil rapido. Dependencias e uso do reparo
antigo estao em [REPARO_165.md](REPARO_165.md).

## Codigo

- `main.c`: configuracao fixa, carregamento das 60 instancias, tabela e CSV.
- `lerInstancias.c`: leitura e liberacao das entradas.
- `cv.c`: solucao inicial, movimentos, avaliacao e escalonamento.
- `SA.c`: calibracao, aceitacao, elite e refinamentos.
- `reparo_alvo.inc`: reparos nativos e integracao CP-SAT, incluido por `cv.c`.

As funcoes desses arquivos possuem comentarios de finalidade; interfaces
publicas e contratos detalhados permanecem nos cabecalhos. O arquivo
`SimulatedAnnealing.cpp` e uma referencia antiga com dependencias ausentes e
nao faz parte da compilacao C acima.

## Verificacao

```powershell
python tests/test_relatorio.py
```

O teste compila uma copia com prazo curto numa pasta temporaria e executa
duas vezes todas as 60 instancias sem argumentos. Verifica a tabela progressiva,
as referencias, os caminhos, a criacao da pasta de saida, a persistencia, o gap
e a rejeicao de cabecalho invalido. O executavel principal conserva o prazo de 30 segundos.
Os testes C em `tests/` verificam os operadores e a viabilidade da busca.
`test_sa_rapido.c` cobre encerramento natural, parada por estagnacao, limite
de macromovimentos e comparacao de atribuicoes com mais de 256 nos.

## Avaliacao de velocidade

As alteracoes foram mantidas apos comparacao nas 60 instancias e confirmacao
nos quatro casos abertos com tres sementes. Metodologia, tempos, qualidade e
fontes congeladas estao no [relatorio de avaliacao](resultados/avaliacao_velocidade_20261106/relatorio.md).
